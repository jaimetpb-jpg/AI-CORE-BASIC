# CATÁLOGO DE REPOS Y BOILERPLATES — NEXUS AI CORE v7.1
## Referencia consolidada por Golden Path. Qué clonar para cada tipo de job.

> Antes de clonar CUALQUIER repo de esta lista: **córrelo por el Repo Trust Check**
> (`05_VPS_BOOTSTRAP/scripts/repo-trust-check.sh <url>`). Ningún prefab entra sin pasar el gate.
> Estado [VERIFICADO jul-2026] salvo lo marcado [VERIFICAR].

---

## GOLDEN PATH: WEB / LANDING

| Repo | Uso | Licencia | Estado |
|---|---|---|---|
| `ixartz/Next-js-Boilerplate` | Landing/web simple. Next.js + Tailwind + tooling, sin peso de SaaS. | MIT | **PROD** |

Stack: Next.js + Tailwind + shadcn/ui. Tests: Playwright. Deploy: Coolify.
Definition of Done: build verde, Lighthouse ≥90, responsive, sin secretos.

---

## GOLDEN PATH: SAAS B2B

| Repo | Uso | Licencia | Estado |
|---|---|---|---|
| `ixartz/SaaS-Boilerplate` | SaaS completo: multi-tenancy, RBAC, i18n, Clerk, Drizzle, Vitest, Playwright, CI/CD. Mejor free 2026. | MIT | **PROD** |
| **Supastarter** | SaaS con multi-tenancy crítica: RLS pre-escrito a nivel DB + trae AGENTS.md para agentes Cursor/Claude Code. | $299 | **LAB — evaluar** |

> Ojo: son DOS repos Ixartz distintos. Para SaaS usa `SaaS-Boilerplate`, NO `Next-js-Boilerplate`.

---

## GOLDEN PATH: RAG / AI PRODUCT

| Base | Uso | Estado |
|---|---|---|
| **Dify** (ya en el core) + pgvector | Chatbots, RAG, AI apps. Dify es la capa RAG del canon. | **PROD** |

> NO metas un boilerplate RAG que duplique Dify. Dify + Qdrant/pgvector ya cubren el stack.

---

## GOLDEN PATH: AUTOMATION (n8n)

| Base | Uso | Estado |
|---|---|---|
| **n8n** (ya en el core) | Workflows de automatización. El Flujo Estrella corre aquí. | **PROD** |
| `n8n-io/self-hosted-ai-starter-kit` | Base de referencia para nodos AI en n8n. | **LAB** |

---

## HERRAMIENTAS EN LAB / FASE-2 (no clonar al core aún)

| Repo | Para qué | Trigger de entrada |
|---|---|---|
| `ComposioHQ/agent-orchestrator` (AO) | Plan B de Agent HQ, multi-tracker | Agent HQ limita por pricing/tier |
| `OpenHands/OpenHands` | Constructor self-hosted soberano | Necesidad de soberanía a escala (FASE-2) |
| `anomalyco/opencode` | Múltiples agentes en paralelo | >3 jobs en cola (FASE-2) |
| agentbox / agenttier | Paralelismo en sandbox / K8s | volumen alto (FASE-2/3) |
| `openai/symphony` | Control plane Codex sobre Linear | solo si gana >25% en A/B vs Agent HQ (LAB) |

---

## REGLA DE USO
1. Elige el repo por Golden Path del job (lo asigna n8n según tipo).
2. Córrelo por `repo-trust-check.sh` → si no es `allow`, para.
3. El agente personaliza ~20%; el ~80% viene del boilerplate.
4. Prefab sobre custom (Principio 1): nunca construyas desde cero lo que un repo maduro ya da.

**Siguiente paso:** para el primer job (landing dental), clona `ixartz/Next-js-Boilerplate`,
pásalo por Trust Check, y sigue `05_VPS_BOOTSTRAP/GUIA_DESARROLLO_VPS.md §3`.
