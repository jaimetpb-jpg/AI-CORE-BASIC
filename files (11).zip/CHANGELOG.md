# CHANGELOG — NEXUS AI CORE
## Registro de cambios y estado actual. Nada se pierde; lo viejo se archiva, no se borra.

> Este archivo deja rastro de qué cambió, por qué, y cómo quedó el proyecto.
> El detalle de cada decisión vive en `00_CANON/DECISIONES_CERRADAS.md`.

---

## ESTADO ACTUAL (v7.1 · jul-2026)

**El flujo está en punto de parada.** Estructura congelada, gobernanza completa.
Lo que falta NO es diseño — es ejecutar 5 jobs reales y medir. El v8 nacerá de
esas métricas, no de más research.

### Canon vigente
- **Identidad de Claude:** `00_CANON/INSTRUCCIONES_PROYECTO_CLAUDE.md` (Regla Cero, principios).
- **Canon de agentes:** `00_CANON/AGENTS.md` (arquitectura, reglas, combo constructor, aliases).
- **Puente Claude Code:** `00_CANON/CLAUDE.md` (rol auditor/arquitecto).
- **Decisiones cerradas:** `00_CANON/DECISIONES_CERRADAS.md`.
- **Flujo:** `01_FLUJO/` (v7 final + anexo v7.1 + diagrama maestro).
- **Artefactos:** `02_ARTEFACTOS_EJECUTABLES/` (litellm, audit, n8n).
- **Roles:** `03_ROLES_Y_SECUENCIA/ROLES_Y_SECUENCIA.md`.
- **Bootstrap:** `04_CLAUDE_CODE/` (prompt + scaffold corregido a v7.1).

---

## HISTORIAL DE CAMBIOS (del canon viejo a v7.1)

### v7.1 (jul-2026) — Gobernanza + combo constructor + limpieza
| Cambio | De | A | Razón |
|---|---|---|---|
| **DeepSeek** | juez/auditor | solo API económica de volumen | Dos auditores bastan; DeepSeek añadía costo sin tercera perspectiva. Confirmado por usuario. |
| **Consenso** | 3-de-3 (con DeepSeek) | 2 auditores Kimi+Claude, unanimidad | Número par → unanimidad, no mayoría inventada. Confirmado. |
| **Constructor** | OpenHands+Aider | Combo 5 con 1 owner/job: Cursor + Codex + Agent HQ + Aider + OpenHands(FASE-2) | Cada herramienta en su fortaleza, verificado contra fuentes. Confirmado. |
| **Cursor** | (no en canon) | cockpit + constructor premium supervisado | Cloud Agents autónomos verificados [cursor.com/cloud]. |
| **Agent HQ** | (negado erróneamente antes) | harness gobernado issue→PR | Verificado real [github.blog/welcome-home-agents]. Se corrigió negación previa. |
| **Boilerplate SaaS** | Ixartz genérico | `ixartz/SaaS-Boilerplate` (repo correcto); Supastarter en LAB | Verificado: había 2 repos Ixartz distintos. |
| **Aliases LiteLLM** | micro/standard/heavy/juez | micro/contexto-largo + auditor-kimi/claude | Refleja DeepSeek fuera del juez. |
| **DeepSeek modelo** | deepseek-chat/reasoner (legacy) | deepseek-v4-flash | **URGENTE: aliases legacy se retiran 24-jul-2026.** |
| **Gobernanza añadida** | — | Repo Trust Check + 10 métricas + triggers + Symphony A/B | Del dictamen externo v7.1, verificado y acreditado. |

### Intacto (NO tocado — decisión explícita del usuario)
Dify (intake+RAG), NocoDB (dashboard), Coolify (deploy), Langfuse (trazas),
n8n (orquestador de negocio), LiteLLM (gateway), Golden Paths, estructura del
Job Ledger. Las discusiones v4→v7.1 fueron sobre motor/auditoría, no sobre esta capa.

### Corrección de scaffold (v7.1)
El `nexus-scaffold.sh` contenía el canon viejo enterrado (DeepSeek juez, aliases
legacy, consenso 3-de-3). Se corrigió quirúrgicamente: cero menciones de
`nexus-juez`, cero `deepseek-chat/reasoner`, cero "3-de-3". Sintaxis bash validada.

### Bloque de arranque VPS (v7.1 — carpeta 05_VPS_BOOTSTRAP)
Se añadió la infraestructura ejecutable para que Claude Code/Cursor/Codex desarrollen
en el VPS de Hostinger:
- `docker-compose.yml` (13 servicios, reciclado y auditado) con los 2 ajustes aplicados:
  base `nexus_ledger`+`nexus_ops` añadidas, config LiteLLM v7.1 montado.
- `postgres/02-ledger-schema-v7.1.sql` — Ledger con las 10 métricas + tabla repo_trust + vista.
- `postgres/init-databases.sh` — reciclado, crea las 6 bases idempotente al arranque.
- `scripts/preflight-check.sh` · `health-check.sh` · `repo-trust-check.sh` — PROBADOS.
  (En repo-trust-check se hallaron y corrigieron 2 bugs durante la prueba real.)
- `GUIA_DESARROLLO_VPS.md` — roles de los 3 agentes + comandos + 11 errores anticipados.
- Cadena de integración compose→init→schema→health verificada. Las 23 variables del
  compose están todas en `.env.example`. [SQL: verificado estructural; VERIFICAR ejecución en VPS]

---

## VERSIONES HISTÓRICAS (archivadas en 99_HISTORICO, NO usar)
- **v4** (`NEXUS_FLUJO_ESTRELLA_v4_MEJORADO.md`) — primera versión del flujo estrella.
- **v5** (`..._v5_DEFINITIVO.md`) — 2 modos + filtro objetivo + skill maturity.
- **v6** (`..._v6_FINAL.md`) — integró Agentic Workflows y capacidades nativas de Codex.
- **v7** → se conserva como base vigente en `01_FLUJO/` (no en histórico) porque v7.1
  es un anexo sobre v7, no un reemplazo.

Diagramas viejos (v4/v5/v6/v7) también archivados en 99_HISTORICO como referencia visual.

---

## PENDIENTES DE EJECUCIÓN (no de diseño)
1. **[HOY · 24-jul límite duro]** LiteLLM → deepseek-v4-flash.
2. Migrar n8n a consenso de 2 auditores.
3. Insertar Repo Trust Check.
4. Extender Job Ledger con 10 métricas.
5. Verificar Copilot Pro+/Enterprise + piloto Agent HQ.
6. Correr 5 jobs reales y medir → de ahí nace el v8.

## DECISIÓN ABIERTA (menor)
- **Boilerplate:** aplicada "Opción 1" (conservadora): Ixartz canon, Supastarter en LAB.
  Si se quiere "Opción 2" (Supastarter a PROD, $299), es cambio de un campo en AGENTS.md.

### Auditoría cruzada de Kimi (v7.1 — hallazgos verificados)
Kimi auditó el paquete y encontró bugs reales. Verificados contra fuentes primarias
y corregidos (Principio de equipo: se celebra y adopta la buena idea venga de quien venga):

**BUGS REALES corregidos:**
- **[CRÍTICO] Config DeepSeek:** `reasoning_effort:"none"` NO apaga thinking en LiteLLM
  actual [VERIFICADO — issue #27453]. DeepSeek v4 defaultea a thinking. Corregido a
  `thinking:{"type":"disabled"}` explícito en nexus-micro y nexus-contexto-largo.
  Mi config previo lo marcaba [VERIFICADO] siendo falso — error de etiqueta corregido.
- **Referencia PNG rota:** NEXUS_FLUJO_v7 apuntaba a nexus-flujo-v7-diagrama.png
  (no existe en el paquete). Corregido a nexus-flujo-v7.1-maestro.png.
- **Conteo de tablas:** AGENTS.md decía "5 tablas"; v7.1 tiene 6 (con repo_trust). Corregido.
- **Scaffold obsoleto:** referencias a nexus-bloque-1-cerebro-bootstrap.sh (inexistente)
  → apuntan a 05_VPS_BOOTSTRAP. Conteo "13 archivos" → 14 real. "v2/Opción C" → v7.1.
- **Compose race condition:** clickhouse sin healthcheck; langfuse-web/worker dependían
  sin condition:service_healthy. Añadidos healthcheck a clickhouse y condiciones healthy.
- **SQL repo_trust:** UNIQUE con lockfile_hash NULL duplicaría filas. Añadido
  UNIQUE NULLS NOT DISTINCT (PG15+) con fallback. Más índices por columnas frecuentes.

**HALLAZGOS de Kimi que resultaron INCORRECTOS (verificados en ambas direcciones):**
- **Permisos audit.md:** Kimi dijo que add-comment necesita pull-requests:write. FALSO
  [VERIFICADO — github.github.com/gh-aw]: en Agentic Workflows el agente corre read-only
  y un job separado hace la escritura vía safe-outputs. `pull-requests:read` es CORRECTO
  y es el patrón oficial recomendado. No se cambió.
- **Conteo de variables:** Verificación confirmó que el compose usa 23 variables con
  ${} y `.env.example` tiene 23 (incluye EVOLUTION_PHONE_VERSION). Corregido.

### Auditoría estructural + completitud (v7.1 — limpieza y faltantes)
Auditoría propia del paquete tras revisión. Soluciones limpias, no parches:

**HIGIENE ESTRUCTURAL corregida:**
- Scripts VPS (preflight/health/repo-trust) estaban DUPLICADOS en 02_ARTEFACTOS y
  05_VPS_BOOTSTRAP/scripts. Eran huérfanos en 02 (las guías referencian 05).
  Eliminados de 02; viven solo en 05 (su hogar canónico). Cero duplicación.
- Doble anidación de carpeta del empaquetado previo: corregida.

**FALTANTES añadidos (completitud para arrancar):**
- **ci.yml** (02_ARTEFACTOS): el CI Harness real que el flujo referencia pero no
  existía como archivo. Lint+typecheck+test+build+audit+secretos. Acciones pinneadas
  por SHA [VERIFICADO — Trivy sufrió tag-poisoning mar-2026; SHA es inmutable, tag no].
  Evita acciones de terceros con tags móviles; usa npm/pip/binarios auditables.
- **CATALOGO_REPOS_BOILERPLATES.md** (03): qué repo clonar por Golden Path,
  consolidado en un solo archivo en vez de disperso en AGENTS.md.

**VERIFICADO sin errores:** 5 scripts bash válidos, 3 YAML válidos + ci.yml, SQL con
10 métricas, nexus_ledger en compose, 21 variables cubiertas en .env.example, config
02=05 idénticos, thinking:disabled en las 4 ocurrencias, cero nexus-juez activo.
